"""generate commands 
generates sql commands to create or alter a database from the config file 
"""

def create_sql(table: str, variables: list, types: list):  # create the command whith the proper data lists
    base = f"CREATE TABLE IF NOT EXISTS {table.lower()}("

    for count, var in enumerate(variables):  # iterate through len of variables
        base += f'''{var} {types[count]}, '''  # add variable, and it's type
    command = base[:-2] + ")"  # remove extra content and append the closing bracket (command done)
    print(command)
    return command


def delete_sql():
    pass