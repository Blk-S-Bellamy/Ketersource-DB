

def pop_stored(database : str, table : str, data_tuple: (tuple, list), indexes : list):
    
    def expand_indexes(indexes_n):
        cond_index = []
        try:
            for num in indexes_n:
                if isinstance(num, str):
                    start, stop = num.split(':')
                    res = [item for item in range(int(start), int(stop) + 1)]

                    for n in res:
                        cond_index.append(n)
                else:
                    cond_index.append(num)
        except (TypeError, ValueError) as e:
            print(
                f'::ERROR:: at \'pop_stored()\' call. given condition list contains non integer: {cond_list} >or> {e} ')
            return e
        cond_index = [*set(cond_index)]
        return cond_index


    def construct_query(database, table, finished_indexes, data_tuple : tuple):
        global tables_w_vars
        base = f"SELECT * FROM {table} WHERE"
        table_list = tables_w_vars[table]

        # loop through the number of indexes to search
        try:
            for i in range(len(finished_indexes)):
                try:
                    addition = f''' {table_list[i]} = "{int(data_tuple[i])}" AND'''
                except (ValueError) as e:
                    addition = f''' {table_list[i]} = "{str(data_tuple[i])}" AND'''
                base += addition
            return base[0:-4]

        except (KeyError, IndexError) as e:
            print(f'::ERROR:: at \"pop_stored\" or \"ps()\" with indexes input \"{finished_indexes}\"',
            f'passed indexes are more than the number of variables in the table ({i})')


    # check a database with a premade select command and return a True or False output
    def check_db(database : str, command : str):
        result = select_all(database, command)
        if len(result) <= 0:
            return False
        else:
            return True


    # iterate through the data provided and remove all duplicates
    def filter_stored(done_indexes, database, table, data_tuple):
        if isinstance(data_tuple, tuple):
            result = check_db(database, construct_query(database, table, done_indexes, data_tuple))
            if result is False:
                return data_tuple
            else:
                return []

        elif isinstance(data_tuple, list):
            non_repeats = []
            
            # iterate through the list of tuples and remove any that are in the database already
            try:
                for item in data_tuple:
                    result = check_db(database, construct_query(database, table, done_indexes, item))
                    if result is False:
                        non_repeats.append(item)
                    else:
                        pass
                return non_repeats

            except:
                print('fail')
        else:
            print(f'::ERROR:: at \"pop_stored()\" or \"ps()\" with input \"{data_tuple}\" (must be str or list)')

    # expand the search indexes 
    done_indexes = expand_indexes(indexes)
    # return the result of a lookup of all data tuples provided
    return filter_stored(indexes, database, table, data_tuple)
