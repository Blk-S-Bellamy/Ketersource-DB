import sqlite3

# will generate the blank question tuple used in insert commands for sqlite3 example: (?, ?, ?, ?)
def generate_blank_par(number):
    variable = '?, ' * number
    v_len = (len(variable) - 2)
    fvariable = variable[0:v_len]
    prefix = '('
    postfix = ')'
    complete = f'{prefix}{fvariable}{postfix}'
    return complete


# input one tuple of variables into a database table
def input_one_(db_pathway, table, num_of_tables : int, insert_tuple):
    par = generate_blank_par(num_of_tables)

    try:
        conn = sqlite3.connect(db_pathway)
        c = conn.cursor()
        c.execute(f"""INSERT INTO {table} VALUES{par}""", insert_tuple)
        conn.commit()
        conn.close()
        return True
    except (KeyError, sqlite3.OperationalError, sqlite3.ProgrammingError) as e:
        print(e)
        return False
    return True


# insert a list of tuples into a database table
# list_of_tuples would look like this: [('data', data), (data, data), (data, data)]
def input_mult_(db_pathway : str, table : str, num_of_tables : int, list_of_tuples : list):
    par = generate_blank_par(num_of_tables)

    try:
        conn = sqlite3.connect(db_pathway)
        c = conn.cursor()
        c.executemany(f"""INSERT INTO {table} VALUES{par}""", list_of_tuples)
        conn.commit()
        conn.close()
        return True
    except (KeyError, sqlite3.OperationalError, sqlite3.ProgrammingError) as e:
        print(e)
        return False


# select one item from a database and it's table
def select_one_(pathway : str, query_ : (str, list)):
    data = retrieve_(pathway, query_, False)
    if type(data) == tuple and len(data) == 1:
        data = data[0]
    return data


# select multiple items from a database and it's table
def select_all_(pathway : str, query_ : (str, list)):
    data = retrieve_(pathway, query_, True)
    if type(data) == tuple and len(data) == 1:
        data = data[0]
    return data


def cond_input(database : str, table : str, data_tuple: (tuple, list), indexes : list):
    remaining = pop_stored(database, table, data_tuple, indexes)
    print(remaining)

    # if user passed a single insert data it will be in tuple form
    if isinstance(remaining, tuple):
        try:
            input_one(database, table, remaining)
        except (KeyError, sqlite3.OperationalError, sqlite3.ProgrammingError) as e:
            print(f'::ERROR:: in cond_input(). passed data is in tuple form but ',
            'contains more than one insert tuple or wrong characters: presort={data_tuple}, postsort=\"{remaining}\"')
    
    # if user passed list of tuples the tuples will be stored in list form.
    elif isinstance(remaining, list):
        try:
            input_mult(database, table, remaining)
        except (KeyError, sqlite3.OperationalError, sqlite3.ProgrammingError) as e:
            print(f'::ERROR:: in cond_input(). passed data is in tuple form but ',
            'contains more than one insert tuple or wrong characters: presort={data_tuple}, postsort=\"{remaining}\"')
    else:
        print(f'::ERROR:: in cond_input(). passed data is not compatible with input parameters,',
        'please refer to docutmentation for correct command usage input=\"{data_tuple}\"')


# used by the select functions to gather results from a database
def retrieve_(conn_path, query_s, all_tf : bool):
    def submit(conn_path, query_s, all_tf):
        # connect, and submit the query to the database then return the result
        try:
            conn = sqlite3.connect(conn_path)
            c = conn.cursor()
            c.execute(query_s)
            if all_tf is True:

                data = c.fetchall()
                ndata = []
                for item in data:
                    if len(item) == 1:
                        ndata.append(item[0])
                    else:
                        ndata.append(item)
                data = ndata
            elif all_tf is False:
                data = c.fetchone()
            conn.close()

            return data
        except (KeyError, sqlite3.OperationalError, sqlite3.ProgrammingError) as e:
            print(e)
            return False
    
    # if there are multiple commands, create a list with the results in order
    result = ()
    multresult = []
    if isinstance(query_s, list):
        for q in query_s:
            multresult.append(submit(conn_path, q, all_tf))
        return multresult
    elif isinstance(query_s, str):
        result = submit(conn_path, query_s, all_tf)
        return result
    else:
        print(f"::ERROR:: in \"retrieve_()\" with query \"{query_s}\". input should be list or str datatypes")