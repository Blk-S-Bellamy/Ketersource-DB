def serialize(data, nested : bool):
    dtypes = [list, dict, tuple]

    def ser_nested(data):
        data_mult = []
        wrap_type = type(data)

        for obj in data:

            if type(obj) in dtypes:
                try:
                    data_mult.append(json.dumps(obj))
                except (ValueError, TypeError, json.JSONDecodeError):
                    # err
                    print('::ERROR:: in serialize')
            else:
                data_mult.append(obj)
        return wrap_type(data_mult)

    if nested is True:
        return ser_nested(data)
    else:

        return json.dumps(data)


# turns serialized data to python objects and return them.
def deserialize(data, nested : bool):
    dtypes = [list, dict, tuple]

    def sser_nested(data):
        data_mult = []
        wrap_type = type(data)

        for obj in data:
            try:
                data_mult.append(json.loads(obj))
            except (ValueError, TypeError, json.JSONDecodeError):
                data_mult.append(obj)

        return wrap_type(data_mult)
    
    # if nested is true, first serialize inner indexes and then return result
    if nested is True:
        return sser_nested(data)
    else:
        # else if nested isn't selected, serialize the whole object and return it
        try:
            ret = json.loads(data)
            return ret
        except (ValueError, TypeError, json.JSONDecodeError):
            print(f'::ERROR:: in deserialize, passed object(s) {data} cannot be deserialized')
            return
