# detect nested objects
def nest_detect(list_, nested_type):
    try:
        result = any(isinstance(i, nested_type) for i in list_)
    except TypeError as e:
        print(f'::ERROR:: in nest_detect with inputs ({list_}, {nested_type}) \"{e}\"')
        exit()
    return result
