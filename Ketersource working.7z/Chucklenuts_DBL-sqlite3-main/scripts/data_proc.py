disallowed_chars = ["<", ">", ":", "/", "|", "?", "*"]
replacement_chars = ["0", "0", "0", "0", "0", "0", "0"]

# take a tuple with lists and expand them into a list of tuples.
def in_tuple(data_tuple : tuple):
    # finds the length of every list in the tuple and then find the longest list out of them all.
    iterations = sorted([len(item) for item in data_tuple if type(item) == list])[-1]
    data_list = []

    for i in range(iterations):
        tup = []
        for index in data_tuple:

            if type(index) == list:
                try:
                    tup.append(index[i])
                except IndexError:
                    tup.append(None)
            else:
                tup.append(index)
        data_list.append(tup)

    return data_list


def str_san(string : str, blank_on_fail=True, mode="replace"):  # sanitize strings for to prevent database errors 
    def bof(string):  # blank return on fail
        return ""

    def eof(string):  # exit on fail
        print(f"::ERROR.string_san():: passed variable is not of string type >> \"{string}\"")
        exit()
    try:
        if mode == "replace":  # replace forbidden char and return result
            for count, char in enumerate(disallowed_chars):
                string = string.replace(char, replacement_chars[count])

            return string
        elif mode == "remove":  # remove forbidden char and return result
            for char in disallowed_chars:
                string = string.replace(char, "")
            return string
        else:
            pass
    except (TypeError, ValueError, AttributeError):  # if an error happens choose the correct failure mode
        if blank_on_fail is False:
            eof(string)
        else:
            bof(string)


def nest_str_san():  # sanitize a list of strings
    pass


def postfix_check(db_name):  # ensure .db is the name postfix and there are no illegal characters
    name = str_san(db_name, mode="remove", blank_on_fail=False)
    if name[-3:] == ".db":
        pass
    else:
        name = f"{name}.db"
    return name
