import re


# includes parameter defining allowed characters
def c_san(name, allowed_chars):

    for char in name:
        if char not in allowed_chars:
            return "", False
        else:
            pass

    if len(name) == 0:
        return "john", False
    else:
        pass
    return name, True


# provide name only, limits to cap, lower, "_", "-", and numbers only
def q_san(name):
    allowed_chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-"
    for i in allowed_chars:
        for char in name:
            if char not in allowed_chars:
                name = name.replace(char, "")
            else:
                pass
    if len(name) == 0:
        name = "-Name Irregular-"
    else:
        pass
    return name


# will return false if name contains illegal characters
def reg_check(name, fix_names=True):
    # check to be sure there are cap, lower, "_", "-" and numbers only
    pattern = "^[A-Za-z0-9_-]*$"
    state = bool(re.match(pattern, name))  # if the name is dangerous

    if state is False and fix_names is True:  # name failed and autofix enabled
        name = q_san(name)
        return name, True
    elif state is True:  # name passed 
        return name, True
    else:
        return name, False  # name failed and autofix disabled