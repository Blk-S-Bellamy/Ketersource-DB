#⣿¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤⣿
#|-------------------Synopsis---------------|
#⣿▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄⣿
"""
fetches and reads config to turn easy syntax into python datatypes used by
Keter Db. Documentation for config can be found at:
https://github.com/Blk-S-Bellamy/Ketersource-DB
"""
#⣿¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤⣿
#|-------------------Imports----------------|
#⣿▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄⣿


import os
import sys
from pathlib import Path
import reg_core as k_reg  # regex functions to make life easier
# fetch the file pathway and find parent directory
current_directory = os.path.dirname(os.path.realpath(__file__))
parent_directory = os.path.dirname(current_directory)  # the parent directory of current dir
stn = 0  # what is being searched for, 0=db name, 1=table name, 2=variable and type
skip_char = ["\n", "#", '"', "'"] # will skip line if starts with these characters


#⣿¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤⣿
#|-------------------Classes----------------|
#⣿▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄⣿


class conf_fail():
    prefix = "::ERROR:: "
    res_prefix = "+--::HINT:: "

    def db_regex(additional):  # failed regex for database name
        prefix = "::ERROR:: "
        res_prefix = "+--::HINT:: "

        failure = f'db name line failed regex "{additional}"'
        resolution = 'database names can only contain 1-0, lowercase a-z and ".db" postfix (database1.db)'
        return f"{prefix}{failure}\n{res_prefix}{resolution}"

    def prep_regex(additional):  # failed regex during prep
        prefix = "::ERROR:: "
        res_prefix = "+--::HINT:: "

        failure = f'config line failed regex "{additional}"'
        resolution = 'config lines can only contain 1-0 and lowercase a-z'
        return f"{prefix}{failure}\n{res_prefix}{resolution}"

    def ind_denom():  # failure in config indentation
        prefix = "::WARNING:: "
        res_prefix = "+--::HINT:: "

        failure = f'config lines do not contain tables or variables"'
        resolution = 'make sure you have indented your table and variable entries if this was a mistake'
        return f"{prefix}{failure}\n{res_prefix}{resolution}"

    def ind_uneven(additional):  # failure in config indentation not being multiples
        prefix = "::ERROR:: "
        res_prefix = "+--::HINT:: "

        failure = f'config indentation is not even. indents must be multiple\nFIX: {additional}'
        resolution = 'make sure indentation is multiples, for example. 0, 4, 8 or 0, 2, 4'
        return f"{prefix}{failure}\n{res_prefix}{resolution}"


#⣿¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤⣿
#|----------------Core Functions------------|
#⣿▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄⣿


def fetch_config():
        # find and open config text file
    try:
        config_file = open(Path(f"{parent_directory}/Keter_Structure.config"), "r")
        config = config_file.readlines()
        config_file.close
        return config
    except FileNotFoundError as e:
        print(f"::ERROR:: \"Keter_Structure.config\" is missing from \"{parent_directory}\"")
        exit()


# remove issue characters from line and prep for reading
def file_prep(file : list, remove_char=["\n"], change_char=["\t", "\\t"]):

    # checkline to see if it should be parsed
    def check_start(line : str):
        global skip_char
        
        # determine if line should be dropped from parser
        try:
            s_char = line[0]  # check first character for skip character
            if s_char in skip_char:
                return False
            else:
                return True
        except Exception:
            return False

    # try to replace all unwanted characters in config before parse
    def reg(line : list):
        # remove certain characters
        for count, item in enumerate(remove_char):
            line = line.replace(item, "")
        
        # replace certain characters with a space (make spaces, tabs the same)
        for count, item in enumerate(change_char):
            line = line.replace(item, " ")
        return line

    # main function
    def main(file : list):
        new_list = []  # will store cleaned config lines
        db_chars = "0123456789abcdefghijklmnopqrstuvwxyz_:.\n\t "  # allowed characters

        # logic flow for processing the file and dropping lines. iterates list of lines
        ''' logic
        skips lines if starts with /n, is empty, or contains a skip char
        if not skipped, line is checked with regex
            line then has tabs and indentations replaced with spaces
            line is saved into cleaned list
        '''
        try:
            for count, line in enumerate(file):

                # make sure line is not skip char or blank
                if check_start(line) is True:

                    # check to make sure line does not have critical format errors
                    if k_reg.c_san(line, db_chars)[1] is True:
                        # replace, remove extra characters and append clean line to list
                        new_list.append(reg(line))
                    else:
                        print(conf_fail.prep_regex(f"{count}:{line}"))  # print error
                        exit()

                else:
                    pass
            
            # return list
            return new_list
        except TypeError as e:
            print(e)
            
    return main(file)  # return cleaned and prepped config for ST functions


# returns config list without spaces and a list of indent scored for generating config lists 
# returns: config:list, indents:list
def ind_score(prepped_config : list):

    # returns lowest number in list that is not 0
    def lowest_num(ind : list):
        start_num = 8
        found = False
        for number in ind:
            if number < start_num and number != 0:
                start_num = number
                found = True
            else:
                pass

        if found is False:
            print(conf_fail.ind_denom())  # warn that there are no tables or variables in config
        else:
            pass
        return start_num  # lowest common denominator

    # try to divide the list by the lcd to simplify indents to 0, 1 or 2
    def lcd_ind(config : list, ind : list, lcd : int):
        ind_list = []  # simplified indentations

        # iterate indents and divide by lcd, exit if failure
        for count, number in enumerate(ind):
            try:
                # preserve 0 index and prevent math errors
                if number == 0:
                    result = 0.0
                else:
                    result = number / lcd
                
                if result.is_integer() is True:
                    result = int(result)
                    ind_list.append(result)
                else:
                    print(conf_fail.ind_uneven(f"{config[count]} (spaces:{number})"))  # error of non multiple indentation
                    exit()

            except (ZeroDivisionError):
                pass
        return ind_list
        
    # returns simplified indent values of 1, 2, or 3
    def main(prepped_config : list):
        ind_list = []  # list of indexed (leading spaces) for config list
        clean_config = []  # config without spaces
        
        # generate the list of index values 
        for line in prepped_config:
            line_proc = line.lstrip()  # line without leading spaces
            ind_list.append(len(line) - len(line_proc))  # current line leading spaces count
            clean_config.append(line_proc.replace(" ", ""))  # add line with spaces removed
            # print(lowest_num(ind_list))
        
        lcd = lowest_num(ind_list)  # find non-0 lowest indent number
        ind_list = lcd_ind(clean_config, ind_list, lcd)  # simplify indents
        return clean_config, ind_list

    clean_config, ind_list = main(prepped_config)
    return clean_config, ind_list


# main logic for the generation of the in-memory configuration dictionaries
def ST_main(config : list, conf_ind):
    
    # 0 -> 2 is not allowed as variables need a table in order to function
    # make sure the passed type is allowed by python
    def type_check():
        # allowed to pass without change
        all_types = ["TEXT",
                     "INTEGER",
                     "REAL",
                     "NULL",
                     "BLOB"
                     ]
        # must be swapped for sqlite3 type before continuing
        fix_types = {"STR" : "TEXT",
                     "INT" : "INTEGER",
                     "FLOAT" : "REAL",
                     "IMAGES" : "BLOB"
                    }


    def main(config : list, conf_ind : list):
        

        working_db = {}  # the current database being built | do I need?
        working_tb = {}  # the tables for the current database | do I need?
        working_var = []  # the current variables being built for the current table

        final_db_struct = {}  # final database are added here
        final_tb_struct = {}  # final tables are added here
        
        curr_db = ""  # save the current database name until final merging
        curr_tb = ""  # save the current table name until final merging

        last_val = 5  # the last state, used to determine behavior of following functions
        cache = ""

        def set_c_db():  # set the current database from the cache
            curr_db = cache
            last_val = cache
            return

        def flush_working(tables=False):  # add the working values to the final memory config and clear them\
            final_db_struct.update(working_db)
            final_db_struct.clear()
            if tables is True:
                final_tb_struct.update(working_tb)
                final_tb_struct.clear()
            else:
                pass
            return

        def flush_working_all():  # flush database and table working dictionaries
            flush_working(tables=True)
            return

        # defines what to do every iteration in order to build the memory config
        indent_rules = {(0, 9) : [set_c_db],
                        (0, 0) : [set_c_db, flush_working_all],
                        (0, 1) : [],
                        (0, 2) : [],
                        (1, 9) : [],
                        (1, 0) : [],
                        (1, 1) : [],
                        (1, 2) : [],
                        (2, 9) : [],
                        (2, 0) : [],
                        (2, 1) : [],
                        (2, 2) : []
                        }



        # enumerate the cleaned config and their indents according to preset rules to build the memory config
        for count, c_line in enumerate(config):
            # conf_ind[count] is the indent value of the current line

            print(conf_ind[count], "==", c_line)
            

            last_val = conf_ind[count]
            


    main(config, conf_ind)

        


def run_parse():
    config = fetch_config()  # fetch config in list form
    config = file_prep(config)  # prep config for parser with regex functions to remove characters or exit
    # print(config)
    # next, count indents and put in list of tuples with number >> (1, 'jokes') etc.
    config, conf_ind = ind_score(config)  # get cleaned config and indentation scores for each line in list form

    ST_main(config, conf_ind)
    for count, item in enumerate(config):
        pass
        # print("IND:", conf_ind[count])
        # print("LINE:", item, "\n")

run_parse()

# logical restraints on allowed intentation
# z_switches = {0 : True, 1 : True, 2 : False} # limits what the next entry can be
# all other are ok, lol