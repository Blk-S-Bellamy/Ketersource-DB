from datetime import datetime

def now_ts():
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # set date-time
    return now