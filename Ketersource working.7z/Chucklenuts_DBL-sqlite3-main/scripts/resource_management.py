"""
will use alternatives to cpu-heavy functions at the cost of minor features.
1. names with illegal characters are NOT fixed but changed to "member"
""" 
cpu_saver = False
