# default available variables types for variable construction. All sqlite3 data types are represented
""" Data types conversion for sqlite3
str = TEXT
int = INTEGER
float = REAL
null = NULL
images = BLOB
"""

# contains all databases the user wants to create and a list with the tables to be put in each
databases_structs = {'jokes.db': ['jokes', 'stuff']}

# keys are defining table names, values are the names of variables and types ("<var-name>", "sql-type") 
table_structs = {'jokes': [
                           ("joke", "TEXT"),
                           ("category", "TEXT"),
                           ("id", "INTEGER")
                           ],
                 'stuff': [
                           ("things", "TEXT"),
                           ("stuff", "TEXT"),

                 ]
                }

"""
# first db
jokes.db
    jokes
        joke:TEXT
        category:TEXT
        id:INTEGER
    stuff
        things:TEXT
        stuff:TEXT

# second db
thingsa.db
    jokes
        joke:TEXT
        category:TEXT
        id:INTEGER
    stuff
        things:TEXT
        stuff:TEXT
"""