import sqlite3
import time
import os
from pathlib import Path
import json
import logging as lg
import importlib
import CNDBL_config as cnf
import CNDBL_structure as structure
import scripts.data_proc as data
import db_scripts.io as io
import db_scripts.sql_gen as gen
# :--:BACKEND:--:

# -version+
ketersource_version = '0.4'
# -pathway and time vars
cwd = os.path.realpath(os.path.dirname(__file__))
unix = time.time()
config_complete = False


# :--:DICTIONARIES AND LISTS:--:

# database class instances which are searchable by name: instance = db_inst[name]
db_inst = {}
# -imported config dictionaries
db_structs = structure.databases_structs  # dict with db, table kv pair
tb_structs = structure.table_structs  # dict with table, (var, type) kv pair


def create_db_instances():
    global db_structs, config_complete
    for item in db_structs:
        # db name
        name = data.postfix_check(item)
        # create db instance
        try:
            database = db(str(cwd), str(name), db_structs[item])
        except KeyError as e:
            print(f"::ERROR:: \"{item}\" is not in structure \"tb_structs\"\n{db_structs}")
            exit()
        # creating a new dict entry to db_dict so the inst is callable by the str name
        db_inst[name] = database
    config_complete = True
    return


# reloads and adds database structures from the config without a restart
def reload_config():
        global db_structs, tb_structs
        # load the config components into memory to speed queries
        importlib.reload(structure)
        db_structs = structure.databases_structs  # dict with db, table kv pair
        tb_structs = structure.table_structs  # dict with table, (var, type) kv pair
        refresh_database_structures()


# clears the console for both Windows and Linux
def clear():
    os.system('cls' if os.name == 'nt' else 'clear')


# contains all information about the database and methods to access db information
class db():
    def __init__(self, pathway, name, tables):
        global tb_structs
        self.pathway = pathway + "/" + data.postfix_check(name)
        self.name = name
        self.tables = tables
        
        # fetch tuples of variables and define as single list if there is only one table, nested list if 2+
        unchk_vars = [tb_structs[table] for table in self.tables]
        if len(unchk_vars) == 1:
            self.variables = unchk_vars[0]
        else:
            self.variables = unchk_vars

    def __str__():
        return f"{self.name} | {self.tables}"

    def initialize():  # initialize the database and 
        create_db_instances()

    def fetch_instance(name):  # fetches an object by its name after startup and returns the object
        global config_complete
        if type(name) == object:
            return name
        
        try:
            return db_inst[data.postfix_check(name)]
        except KeyError:
            if config_complete is False:
                print(f'::ERROR:: config was not refreshed at runtime, please do so with \"rds()\" at the start of the calling program.')
            else:
                print(f'::ERROR:: passed database name {data.postfix_check(name)} could not be found in database dict')
            exit()

    def get_attributes(db_name : str):  # return all attributes of a selected database
        name, pathway, tables, variables = db.attributes(db.fetch_instance(db_name))
        return name, pathway, tables, variables

    def attributes(self):  # fetch all database attributs with db object
        return self.name, self.pathway, self.tables, self.variables

    def get_pathway():  # fetch a db pathway by it's name in string form
        pathway = db.pthway
    
    def pthway(self):  # fetch database pathway with db object
        return self.pathway

    def get_tables(db_name):  # fetch a db table list by it's name in string form
        tables = db.tables(db.fetch_instance(db_name))
        return tables

    def tables(self):  # fetch table with db object
        return self.tables

    def get_vars(tb_name):  # fetch db variables by the database name in string form
        variables = db.vari(db.fetch_instance(tb_name))
        return variables

    def vari(self):  # fetch variables with db object
        return self.variables

    def get_size(db_name):  # fetch db size in bytes with a db object
        byte_size = db.size(db.fetch_instance(db_name))
        return byte_size

    def size(self):  # fetch a db size in bytes by it's name in string form
        try:
            size = os.path.getsize(Path(self.pathway + "/" + self.name))
            return size
        except FileNotFoundError:
            return 0

    def get_table_var(table : str):  # pass a table in to get table variables
        return db.table_var(table, ret_values="var")

    def get_table_types(table : str):
        return db.table_var(table, ret_values="type")

    def get_table_mix(table : str):  # pass a table in to get variables and their types
        return db.table_var(table, ret_values="mix")

    def table_var(table : str, ret_values="var"):  # fetch table information using table dict
        """use the following to fetch certain table info:
        var (list of table variables)
        mix (list of tuples with variables and their types)
        type (list of table types for the vars)

        to extract types from mixed use:
        variables = [item[0] for item in mixed]
        types = [item[1] for item in mixed]
        """        
        global tb_structs
        mixed = tb_structs[table]

        if ret_values == "mix":
            return mixed
        else:
            pass
        variables = [item[0] for item in mixed]

        if ret_values == "var":
            return variables
        elif ret_values == "type":
            types = [item[1] for item in mixed]
            return types

    def apply_changes(delete_allowed=False):  # apply changes in config to the database
        global db_inst, config_complete 
        if config_complete is False:
            print("::WARNING:: db was not initialized at runtime with \"db.initialize()\", initializing..")
            db.initialize()

        for inst in db_inst.values():  # for database initialized, make changes
            db.changes(inst)

    def changes(self):  # generate and apply changes to the database
        create_commands, delete_commands = db.gen_commands(self)
        db.execute(self.name, create_commands)
        

    def execute(db_name : str, command : (str, list)):  # execute sql to a database using the name
        inst = db.fetch_instance(db_name)
        result = db.exe(inst, db_name, command)
        return result

    def exe(self, database : str, command : (str, list)):  # execute a single or list of commands in a db by instance
        def submit(database, command):
            conn_path = Path(db.pthway(self))
            conn = sqlite3.connect(conn_path)
            c = conn.cursor()
            try:
                c.execute(command)
                conn.commit()
                conn.close()
            except (KeyError, sqlite3.OperationalError, sqlite3.ProgrammingError) as e:
                print(e)

        # determine if there are multiple commands or just one
        if isinstance(command, list):
            for com in command:
                submit(database, com)
        elif isinstance(command, str):
            submit(database, command)
        else:
            print(f"::ERROR:: in \"execute()\" with query \"{command}\". input should be list or str datatypes")
        

    def gen_commands(self, delete_allowed=False):
        global db_structs, tb_structs
        create_commands = []  # commands generated to create new database structures
        delete_commands = []  # commands generated to delete new database structures
        tables = self.tables
        for count, tb in enumerate(tables):
            mixed = tb_structs[tb]  # tuples with variables and their types of the current table
            variables = [item[0] for item in mixed]  # fetches a list of variable names
            types = [item[1] for item in mixed]  # fetches a list of variable types
            create_commands.append(gen.create_sql(tb, variables, types))  # append the command to a list to execute
        return create_commands, delete_commands

    def input_one(db_name : str, table : str, insert_tuple : tuple):
        inst = db.fetch_instance(db_name)
        tbls_len = len(db.get_table_mix(table))
        print(db.tables(inst))
        path = db.pthway(inst)
        io.input_one_(path, table, tbls_len, insert_tuple)

    def input_mult(db_name : str, table : str, insert_tuple : tuple):
        inst = db.fetch_instance(db_name)
        tbls_len = len(db.tables(inst))
        path = db.pthway(inst)
        io.input_one_(path, table, tbls_len, insert_tuple)

    def select_one():
        pass

    def select_mult():
        pass


db.initialize()  # initializes the database structure into memory
db.apply_changes()
# db.input_one("jokes.db", "jokes", ("funny", "thing", 1000))