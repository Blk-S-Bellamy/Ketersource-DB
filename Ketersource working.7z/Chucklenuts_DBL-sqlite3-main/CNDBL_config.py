# To change database structure please edit "CNDBL_structure.py"

# -database name checks
check_chars = True
disallowed_chars = ["<", ">", ":", "/", "|", "?", "*"]
num_of_periods = 1
